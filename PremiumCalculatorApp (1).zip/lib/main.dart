import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Premium Calculator',
      theme: ThemeData.dark(),
      home: CalculatorHome(),
    );
  }
}

class CalculatorHome extends StatefulWidget {
  @override
  _CalculatorHomeState createState() => _CalculatorHomeState();
}

class _CalculatorHomeState extends State<CalculatorHome> {
  String _expression = '';

  void numClick(String text) {
    setState(() {
      _expression += text;
    });
  }

  void clear(String text) {
    setState(() {
      _expression = '';
    });
  }

  void evaluate(String text) {
    try {
      setState(() {
        _expression = _expression.isNotEmpty ? _expression : '0';
      });
    } catch (e) {
      setState(() {
        _expression = 'Error';
      });
    }
  }

  Widget calcButton(String text, Color color) {
    return ElevatedButton(
      onPressed: () {
        if (text == 'C') {
          clear(text);
        } else if (text == '=') {
          evaluate(text);
        } else {
          numClick(text);
        }
      },
      child: Text(text, style: TextStyle(fontSize: 24)),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        padding: EdgeInsets.all(20),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Premium Calculator')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 20),
            child: Text(_expression, style: TextStyle(fontSize: 48)),
          ),
          Divider(),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var label in ['7', '8', '9', '/', '4', '5', '6', '*',
                                 '1', '2', '3', '-', '0', '.', '=', '+', 'C'])
                calcButton(label, Colors.blue),
            ],
          )
        ],
      ),
    );
  }
}
